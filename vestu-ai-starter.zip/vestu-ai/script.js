const $ = (selector) => document.querySelector(selector);
const chatForm = $("#chatForm");
const messageInput = $("#messageInput");
const messages = $("#messages");
const welcome = $("#welcome");
const sendBtn = $("#sendBtn");
const fileInput = $("#fileInput");
const attachmentPreview = $("#attachmentPreview");
const historyList = $("#historyList");
let attachedFile = null;
let attachedDataUrl = null;
let currentMessages = [];
let chats = [];
let recognition = null;
let toastTimer;

function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove("show"), 2800);
}
function showChat() {
  welcome.hidden = true;
  messages.hidden = false;
}
function addMessage(role, text, isError = false) {
  showChat();
  const row = document.createElement("div");
  row.className = `message ${role}${isError ? " error" : ""}`;
  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "V";
    row.appendChild(avatar);
  }
  const body = document.createElement("div");
  body.className = "message-body";
  body.textContent = text;
  row.appendChild(body);
  messages.appendChild(row);
  row.scrollIntoView({ behavior: "smooth", block: "end" });
  return body;
}
function renderHistory() {
  historyList.replaceChildren();
  chats.slice().reverse().forEach((chat) => {
    const button = document.createElement("button");
    button.className = "history-item";
    button.textContent = chat.title || "Percakapan baru";
    button.title = button.textContent;
    button.addEventListener("click", () => loadChat(chat.id));
    historyList.appendChild(button);
  });
}
function saveCurrentChat() {
  if (!currentMessages.length) return;
  const firstUser = currentMessages.find(m => m.role === "user");
  const title = firstUser ? firstUser.content.slice(0, 36) : "Percakapan baru";
  const id = Date.now();
  chats.push({ id, title, messages: currentMessages.slice() });
  renderHistory();
}
function loadChat(id) {
  const chat = chats.find(c => c.id === id);
  if (!chat) return;
  messages.replaceChildren();
  welcome.hidden = true;
  currentMessages = chat.messages.slice();
  currentMessages.forEach(m => addMessage(m.role, m.content));
  closeSidebar();
}
function resetChat() {
  if (currentMessages.length) saveCurrentChat();
  currentMessages = [];
  messages.replaceChildren();
  welcome.hidden = false;
  messageInput.value = "";
  clearAttachment();
  closeSidebar();
  messageInput.focus();
}
function closeSidebar() { $("#sidebar").classList.remove("open"); }
$("#newChat").addEventListener("click", resetChat);
$("#openSidebar").addEventListener("click", () => $("#sidebar").classList.add("open"));
$("#closeSidebar").addEventListener("click", closeSidebar);
document.querySelectorAll(".suggestion").forEach(btn => btn.addEventListener("click", () => {
  messageInput.value = btn.dataset.prompt;
  messageInput.focus();
  autoResize();
}));

function autoResize() {
  messageInput.style.height = "auto";
  messageInput.style.height = Math.min(messageInput.scrollHeight, 150) + "px";
}
messageInput.addEventListener("input", autoResize);
messageInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    chatForm.requestSubmit();
  }
});
$("#attachBtn").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", async () => {
  attachedFile = fileInput.files?.[0] || null;
  attachedDataUrl = null;
  if (!attachedFile) return;
  if (attachedFile.size > 5 * 1024 * 1024) {
    toast("Ukuran file maksimal 5 MB.");
    clearAttachment();
    return;
  }
  if (attachedFile.type.startsWith("image/")) {
    attachedDataUrl = await readAsDataURL(attachedFile);
    attachmentPreview.innerHTML = "";
    const img = document.createElement("img");
    img.src = attachedDataUrl;
    img.alt = "Pratinjau lampiran";
    attachmentPreview.append(img);
  } else {
    attachmentPreview.replaceChildren();
  }
  const label = document.createElement("span");
  label.textContent = attachedFile.name;
  const remove = document.createElement("button");
  remove.type = "button";
  remove.textContent = "×";
  remove.setAttribute("aria-label", "Hapus lampiran");
  remove.addEventListener("click", clearAttachment);
  attachmentPreview.append(label, remove);
  attachmentPreview.hidden = false;
});
function readAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
function clearAttachment() {
  attachedFile = null;
  attachedDataUrl = null;
  fileInput.value = "";
  attachmentPreview.replaceChildren();
  attachmentPreview.hidden = true;
}
$("#micBtn").addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    toast("Dikte suara belum didukung browser ini. Coba Chrome di Android.");
    return;
  }
  if (recognition) {
    recognition.stop();
    recognition = null;
    $("#micBtn").textContent = "🎙";
    return;
  }
  recognition = new SpeechRecognition();
  recognition.lang = "id-ID";
  recognition.interimResults = false;
  recognition.onresult = event => {
    messageInput.value = (messageInput.value + " " + event.results[0][0].transcript).trim();
    autoResize();
  };
  recognition.onerror = () => toast("Mikrofon tidak dapat digunakan. Periksa izin browser.");
  recognition.onend = () => { recognition = null; $("#micBtn").textContent = "🎙"; };
  recognition.start();
  $("#micBtn").textContent = "⏹";
  toast("Silakan bicara. Ketuk tombol mikrofon untuk berhenti.");
});

chatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = messageInput.value.trim();
  let fileText = "";
  if (!text && !attachedFile) return;
  if (attachedFile && !attachedFile.type.startsWith("image/")) {
    if (/\.(txt|md|csv|json)$/i.test(attachedFile.name)) {
      fileText = await attachedFile.text();
      if (fileText.length > 20000) fileText = fileText.slice(0, 20000) + "\n[Isi file dipotong karena terlalu panjang]";
    } else {
      toast("Untuk sekarang, lampirkan gambar atau file TXT, MD, CSV, atau JSON.");
      return;
    }
  }
  const displayText = text + (attachedFile ? `\n📎 ${attachedFile.name}` : "");
  addMessage("user", displayText);
  currentMessages.push({ role: "user", content: text || "Tolong periksa lampiran saya." });
  const requestMessages = currentMessages.slice(-12);
  const image = attachedDataUrl;
  const body = addMessage("assistant", "Sedang berpikir…");
  body.parentElement.classList.add("loading");
  const outgoingText = text + (fileText ? `\n\nIsi file ${attachedFile.name}:\n${fileText}` : "");
  messageInput.value = "";
  autoResize();
  const payload = { messages: requestMessages, message: outgoingText, image };
  clearAttachment();
  sendBtn.disabled = true;
  try {
    const response = await fetch("/.netlify/functions/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Gagal menghubungi AI.");
    body.textContent = data.reply || "AI belum memberikan jawaban.";
    currentMessages.push({ role: "assistant", content: body.textContent });
  } catch (error) {
    body.textContent = `Belum terhubung: ${error.message}\n\nPastikan Netlify Function sudah dipasang dan API key disetel di Environment variables.`;
    body.parentElement.classList.add("error");
    currentMessages.pop();
  } finally {
    body.parentElement.classList.remove("loading");
    sendBtn.disabled = false;
    messageInput.focus();
  }
});
