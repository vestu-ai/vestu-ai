// VESTU AI backend for Netlify Functions.
// Set OPENAI_API_KEY in Netlify site environment variables. Never put it in frontend files.
exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers, body: "" };
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Gunakan metode POST." }) };
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "API key belum disetel di Netlify Environment variables." }) };
  }

  try {
    const payload = JSON.parse(event.body || "{}");
    const message = String(payload.message || "").slice(0, 20000);
    const image = typeof payload.image === "string" && payload.image.startsWith("data:image/") ? payload.image : null;
    const history = Array.isArray(payload.messages) ? payload.messages.slice(-10) : [];
    const content = [{ type: "input_text", text: message || "Tolong periksa gambar yang saya lampirkan." }];
    if (image) content.push({ type: "input_image", image_url: image });

    const input = history.map(item => ({
      role: item.role === "assistant" ? "assistant" : "user",
      content: [{ type: "input_text", text: String(item.content || "").slice(0, 10000) }]
    }));
    // Replace the final user message with the latest message and optional image.
    if (input.length && input[input.length - 1].role === "user") input.pop();
    input.push({ role: "user", content });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "Kamu adalah VESTU AI, asisten yang ramah dan membantu. Jawab dalam bahasa yang digunakan pengguna, utamakan bahasa Indonesia, jelaskan dengan jelas dan jujur.",
        input,
        max_output_tokens: 1200
      })
    });
    const result = await response.json();
    if (!response.ok) {
      const message = result?.error?.message || "Penyedia AI menolak permintaan.";
      return { statusCode: response.status, headers, body: JSON.stringify({ error: message }) };
    }
    const reply = (result.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n").trim();
    return { statusCode: 200, headers, body: JSON.stringify({ reply: reply || "Maaf, aku belum bisa menjawab itu." }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Terjadi kesalahan pada server VESTU AI." }) };
  }
};
