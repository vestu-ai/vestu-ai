VESTU AI — PANDUAN PEMASANGAN (HP ANDROID, TANPA TERMUX)

ISI FOLDER
- index.html: struktur halaman
- style.css: desain responsif
- script.js: interaksi chat, lampiran, dan dikte browser
- netlify/functions/chat.js: backend untuk memanggil AI dengan aman
- netlify.toml: konfigurasi Netlify

CARA UPLOAD KE GITHUB
1. Buka repositori GitHub VESTU AI.
2. Upload semua file dan folder dari ZIP ini. Pastikan index.html ada di root repositori.
3. Pastikan folder netlify/functions/chat.js ikut ter-upload.
4. Commit perubahan.

CARA DEPLOY DI NETLIFY
1. Buka Netlify dan pilih proyek yang terhubung ke repositori GitHub tersebut.
2. Buka Site configuration / Project configuration > Environment variables.
3. Tambahkan OPENAI_API_KEY dengan API key milikmu sebagai value. Jangan masukkan API key ke file HTML atau JS.
4. Opsional: tambahkan OPENAI_MODEL dengan nilai gpt-4.1-mini.
5. Untuk build settings: publish directory "." dan functions directory "netlify/functions". netlify.toml di proyek ini sudah mengatur nilai tersebut.
6. Trigger deploy baru dari tab Deploys.
7. Setelah deploy berhasil, buka alamat situs Netlify dan coba kirim pesan.

PENTING
- API dari penyedia model dapat mengenakan biaya. Periksa saldo, batas penggunaan, dan harga akun API milikmu.
- Jangan pernah membagikan API key di chat, screenshot, atau repositori publik.
- Tombol dikte memakai fitur speech recognition browser dan dukungannya tergantung browser/perangkat.
- Gambar dan file teks sederhana dapat dilampirkan. PDF belum diproses pada versi awal ini.
- Chat ini mengirim permintaan ke Netlify Function. Tanpa deploy function dan API key yang benar, AI belum akan menjawab.
- Ini adalah versi awal web. Belum merupakan APK Google Play Store.
