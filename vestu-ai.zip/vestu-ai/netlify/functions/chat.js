const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

exports.handler = async event => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  };

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Gunakan metode POST." })
    };
  }

  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return {
      statusCode: 503,
      headers,
      body: JSON.stringify({
        error: "API belum dikonfigurasi di Netlify."
      })
    };
  }

  let body;

  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: "Pesan tidak valid." })
    };
  }

  const message = String(body.message || "").trim().slice(0, 4000);

  if (!message) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: "Pesan masih kosong." })
    };
  }

  const previous = Array.isArray(body.history)
    ? body.history.slice(-10)
    : [];

  const contents = [];

  for (const item of previous) {
    if (!item || typeof item.text !== "string") continue;

    contents.push({
      role: item.role === "user" ? "user" : "model",
      parts: [{ text: item.text.slice(0, 4000) }]
    });
  }

  contents.push({
    role: "user",
    parts: [{ text: message }]
  });

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{
              text: "Kamu adalah VESTU AI, asisten ramah yang terutama menggunakan bahasa Indonesia. Jawab dengan jelas, jujur, dan sopan. Jangan mengarang fakta."
            }]
          },
          contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 900
          }
        })
      }
    );

    const result = await response.json();

    if (!response.ok) {
      return {
        statusCode: response.status === 429 ? 429 : 502,
        headers,
        body: JSON.stringify({
          error: response.status === 429
            ? "Kuota AI tercapai. Coba lagi nanti."
            : "Layanan AI gagal. Periksa model, API key, dan log Netlify."
        })
      };
    }

    const reply = (result.candidates?.[0]?.content?.parts || [])
      .map(part => part.text || "")
      .join("")
      .trim();

    if (!reply) {
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({ error: "AI belum menghasilkan jawaban." })
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reply })
    };
  } catch {
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({ error: "Gagal menghubungi penyedia AI." })
    };
  }
};