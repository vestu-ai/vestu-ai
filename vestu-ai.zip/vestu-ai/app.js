const form = document.querySelector("#chatForm");
const input = document.querySelector("#message");
const chat = document.querySelector("#chat");
const statusEl = document.querySelector("#status");
const sendBtn = document.querySelector("#sendBtn");
const welcome = document.querySelector("#welcome");

const STORAGE_KEY = "vestu-chat-v1";
let history = [];

try {
  history = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  if (!Array.isArray(history)) history = [];
} catch {
  history = [];
}

history = history
  .filter(x => x && ["user", "model"].includes(x.role) && typeof x.text === "string")
  .slice(-30);

function saveHistory() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(-30)));
  } catch {}
}

function renderMessage(role, text) {
  const div = document.createElement("div");
  div.className = "message " + (role === "user" ? "user" : "assistant");
  div.textContent = text;
  chat.appendChild(div);
  welcome.hidden = chat.children.length > 0;
  div.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function renderHistory() {
  chat.replaceChildren();
  history.forEach(item => renderMessage(item.role, item.text));
  welcome.hidden = chat.children.length > 0;
}

async function sendMessage(value) {
  const message = value.trim();
  if (!message || sendBtn.disabled) return;

  const oldHistory = history.slice(-10);
  renderMessage("user", message);
  history.push({ role: "user", text: message });
  saveHistory();

  input.value = "";
  sendBtn.disabled = true;
  statusEl.textContent = "VESTU sedang berpikir...";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history: oldHistory })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Layanan AI tidak tersedia.");

    renderMessage("assistant", data.reply);
    history.push({ role: "model", text: data.reply });
    saveHistory();
  } catch (error) {
    renderMessage("assistant", "Maaf, belum bisa menjawab. " + error.message);
  } finally {
    sendBtn.disabled = false;
    statusEl.textContent = "";
    input.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

document.querySelector("#clearBtn").addEventListener("click", () => {
  if (!confirm("Hapus riwayat percakapan di perangkat ini?")) return;
  history = [];
  saveHistory();
  chat.replaceChildren();
  welcome.hidden = false;
});

renderHistory();

if ("serviceWorker" in navigator && location.protocol === "https:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}